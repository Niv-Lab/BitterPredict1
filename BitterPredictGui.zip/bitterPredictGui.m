function varargout = bitterPredictGui(varargin)
%BitterPredict GUI version with Excel file or csv/txt  is working.
%In case of any Bug or issue lease contact ayana.wiener@mail.huji.ac.il

% BITTERPREDICTGUI MATLAB code for bitterPredictGui.fig
%      BITTERPREDICTGUI, by itself, creates a new BITTERPREDICTGUI or raises the existing
%      singleton*.
%
%      H = BITTERPREDICTGUI returns the handle to a new BITTERPREDICTGUI or the handle to
%      the existing singleton*.
%
%      BITTERPREDICTGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in BITTERPREDICTGUI.M with the given input arguments.
%
%      BITTERPREDICTGUI('Property','Value',...) creates a new BITTERPREDICTGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before bitterPredictGui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to bitterPredictGui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help bitterPredictGui

% Last Modified by GUIDE v2.5 26-Jul-2017 16:32:02

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @bitterPredictGui_OpeningFcn, ...
                   'gui_OutputFcn',  @bitterPredictGui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before bitterPredictGui is made visible.
function bitterPredictGui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to bitterPredictGui (see VARARGIN)

% Choose default command line output for bitterPredictGui
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
global bitterPredictParams;
bitterPredictParams=struct();
global model;

%first check if model fiile exist.
 if (exist('bitterPredict2017.mat', 'file') == 2)
     bitterPredictParams.modelFile='bitterPredict2017.mat';
     try 
           model=load(bitterPredictParams.modelFile); %model path + file
     catch
        display (['ERROR:  failed to load bitterPredict2017.mat\n  Please make sure to fill the model file path  in the options panel'])
     end
 else
      bitterPredictParams.modelFile='';
         display (['WARNING : bitterPredict2017.mat was not found in Matlab path. Please make sure to fill the model file path in the options panel'])
 end 
     
     
%try to uploadmodel from current directory 
%if not found ask the user to 

% UIWAIT makes bitterPredictGui wait for user response (see UIRESUME)
% uiwait(handles.figure1);

%=========================================
%help functions written by the auther
%=====================================
function [ outSet,IndexesInBitterDomain,IndexesNotInBitterDomain ] = inBitterDomain( setOrderdProp )

%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
%assuming 59 properties 
MW_index=48;
AlogP_index=49;
MW_thr=700;
AlogP_BottomThr=-3;
AlogPUperThr=7;
IndexesInBitterDomain=(setOrderdProp(:,MW_index)<=MW_thr) & (setOrderdProp(:,AlogP_index)>= AlogP_BottomThr)  & (setOrderdProp(:,AlogP_index)<=AlogPUperThr);
outSet=setOrderdProp(IndexesInBitterDomain,:);
IndexesNotInBitterDomain=~IndexesInBitterDomain;

function [predictions_out,Score_out]=AdaBoostPredict(algosStruct)
%assuming one model just to predict on input set
    [predictions,Score]=algosStruct.bitterPredict.predict(params.outGroupData);
    predictions_out=predictions;
    Score_out=Score;

    %TODo check what is in our case 
    if(iscell(predictions))
        predictions=cellfun(@str2num,predictions); 
    end

    negativeP=sum(predictions==-1);
    posP=sum(predictions==1);
    % to do maybe change to default -1
    if(isfield(bitterPredictParams,'thr'))
        posP=sum(Score(:,2)>=bitterPredictParams.thr);
        negativeP=sum(Score(:,1)<bitterPredictParams.thr);
    end
    

%===============================
% callback functions
%=====================
% --- Outputs from this function are returned to the command line.
function varargout = bitterPredictGui_OutputFcn(hObject, eventdata, handles) 

% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbtton_predict.
function pushbtton_predict_Callback(hObject, eventdata, handles)

% hObject    handle to pushbtton_predict (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%get fileName

global bitterPredictParams;
global model;

%check that model exist
if(isempty(model))
    %todo try to read it from the file specfied by the user
end 
 datafile=get(handles.edit_browse,'string');
 if(~datafile)
     Title='Error'
     h = msgbox('You must provide input file',Title);
     return;
 end
 %oenfile:
 
 propForModelOrdered={'#stars','#amine','#amidine','#acid','#amide','#rotor','#rtvFG','CNS','dipole','SASA','FOSA','FISA','PISA','volume','donorHB','accptHB','dip^2/V','ACxDN^.5/SA','glob','QPpolrz','QPlogPC16','QPlogPoct','QPlogPw','QPlogPo/w','QPlogS','CIQPlogS','QPlogHERG','QPPCaco','QPlogBB','QPPMDCK','QPlogKp','IP(eV)','EA(eV)','#metab','QPlogKhsa','HumanOralAbsorption','PercentHumanOralAbsorption','SAfluorine','SAamideO','PSA','RuleOfFive','RuleOfThree','#ringatoms','#in34','#in56','#noncon','#nonHatm','MW','AlogP','RB','HeavyAtomCount','RingCount','Estate','MR','Polar','Num atoms','Num aromatic rings','ChiralCenterCount','Total charge'};

fileNameSplit= strsplit(datafile,'.');
% todo insert to handles or set as global
fileType=fileNameSplit{2};
if(regexp(fileType, 'xls*'))
    bitterPredictParams.type=fileType;
else
    if (strcmp(fileType,'csv'))
        bitterPredictParams.type=fileType;
    else
         bitterPredictParams.type='txt';
    end
end
 bitterPredictParams.setName='';
if (~isempty(handles.edit_setName.String))
   bitterPredictParams.setName=handles.edit_setName.String;
end
%first row properties
%if(regexp(fileNameSplit{end}, 'xls*'))
%todo add option of reading from specfic sheet
%upload file
   try
      propTable=readtable(datafile);
   catch ME
        mb = msgbox(['There was a problem uploading the file.\n Got error:' ME.message],'Error','error');
    return;
   end
    num_cols=size(propTable,2);
    num_rows=size(propTable,1);
    first_prop=propTable.Properties.VariableNames{1};
    firstNumericColumn=1;
     for p=1:length(propTable.Properties.VariableNames)
         prop=propTable.Properties.VariableNames{p};
         if (isnumeric(propTable.(prop)))
            firstNumericColumn=p;
             break;
         end
     end
     bitterPredictParams.numberOfIdsColumnsToPrint=max(firstNumericColumn-1,1);
     orderedData=[];
     errorWithProp=false;
     for i=1:length(propForModelOrdered)
            currProp=propForModelOrdered{i};
            %change property name to reatTable format 
            expressionNumberSign='#';
            replaceWith='x_';
            currProp = regexprep(currProp,expressionNumberSign,replaceWith);
            expressionSpecialChars='[\^\/\.\(\)]';
            replaceWith='_';
            currProp = regexprep(currProp,expressionSpecialChars,replaceWith);
            expressionSpace='\s';
            replaceWith='';
            currProp = regexprep(currProp,expressionSpace,replaceWith);
            %check that all required descriptors exist in the input file
            if(any(strcmp(lower(currProp), lower(propTable.Properties.VariableNames))))
                   propIndex=find(strcmp(lower(currProp), lower(propTable.Properties.VariableNames)));
                   orderedData(:,i)=propTable.(propTable.Properties.VariableNames{propIndex});
            else
                  mb = msgbox(['Property: ', currProp , 'was not found. Please check your input file and mak sure it contains the missing property '],'Error','error');
                errorWithProp=true;
                 return;
            end     
            if(sum(isnan(orderedData(:,i))))
                   mb = msgbox(['The data include non numeric cells , a non numeric elemtes were found in the : "' currProp '" property please fix the input data'],'Error','error');
                  errorWithProp=true;
                return;
            end
      end    
if(~errorWithProp)
    %get only molecules in bitter domain
    [setIndomain,IndexesInBitterDomain,IndexOutOfBitterDomain]=inBitterDomain(orderedData);
    %run Adaboost and gett predictions 
    %todo add here take the model from params (and load the 
    try
    [predictions,Score]=model.bitterModel2017.ada200.predict(setIndomain);
    catch
        %todo message box problem with model file
    end 
    resultTable=table();
    idIsIndexs=false;
    if(bitterPredictParams.numberOfIdsColumnsToPrint==1)
        %check if first prop is part of the data
        if strcmp(first_prop, propForModelOrdered)
           resultTable.Index=num2cell(1:num_rows);
           idIsIndexs=true;
        end
    end
    if (~idIsIndexs)
       
        for i=1:(bitterPredictParams.numberOfIdsColumnsToPrint) 
            resultTable.(propTable.Properties.VariableNames{i})=propTable{:,i};
        end
    end
    %fill put
    InBitterDomain=zeros(size(orderedData,1),1);
    InBitterDomain(IndexesInBitterDomain)=1;
    resultTable.InBitterDomain=InBitterDomain;
    
    out_predictions=nan(size(orderedData,1),1);
    out_predictions(IndexesInBitterDomain)=predictions;
    resultTable.predictions=out_predictions;
    
    out_score=nan(size(orderedData,1),1);
    out_score(IndexesInBitterDomain)=Score(:,2);
    resultTable.score=out_score;
    
    predictedBitter=sum(predictions>0);
    predictedNonBitter=sum(predictions<0);
    %save file 
    saveOutputPath=get(handles.edit_outputPath,'string');
    fileName=[bitterPredictParams.setName 'bitterPredict_'  datestr(now, 'HH_MM_dd-mmm') '.' bitterPredictParams.type];
    saveFileInLocalFolder=true;
    if (saveOutputPath)
        try
            outFile=[saveOutputPath fileName];
            writetable(resultTable,outFile);
            saveFileInLocalFolder=false;
        catch
            saveFileInLocalFolder=true;
        end
    end
    if(isempty(saveOutputPath)) || (saveFileInLocalFolder)
        writetable(resultTable,fileName);
    end
    shortResults = sprintf('Prediction Results:\n\nNumber of molecules ready  for prediction is : %d\n Number of molecules in bitterDomain: %d \n Number of  molecules predicted to be bitter is: %d \n Number of  molecules predicted to be non-bitter: %d',length(IndexesInBitterDomain),sum(IndexesInBitterDomain),predictedBitter,predictedNonBitter);
    %print stat in new window or panel:
    uiwait(msgbox(shortResults,'Prediction Results'));
end
    


% --- Executes on button press in radiobutton_stat.
function radiobutton_stat_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton_stat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton_stat


% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton2

%uigetfile(FilterSpec)

function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_browse_Callback(hObject, eventdata, handles)
% hObject    handle to edit_browse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_browse as text
%        str2double(get(hObject,'String')) returns contents of edit_browse as a double


% --- Executes during object creation, after setting all properties.
function edit_browse_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_browse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_browse.
function pushbutton_browse_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_browse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename, pathname]=uigetfile({'*.xls;*.xlsx;*.csv;*.txt'},'upload file');
if isequal(filename,0) || isequal(pathname,0)
    return;
end
 %write the chosen file full name to the browse text box
 set(handles.edit_browse,'string',fullfile(pathname,filename));


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

function [firstDataColumn]=getDataFirstCol(raw)
    firstDataRaw=raw(2,:);
    numericCol = cellfun(@(x) isnumeric(x) && numel(x)==1, firstDataRaw);
    firstDataColumn=find(numericCol,1);


% --- Executes on button press in radiobutton4.
function radiobutton4_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton4


% --- Executes on button press in radiobutton5.
function radiobutton5_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton5



function edit_outputPath_Callback(hObject, eventdata, handles)
% hObject    handle to edit_outputPath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_outputPath as text
%        str2double(get(hObject,'String')) returns contents of edit_outputPath as a double


% --- Executes during object creation, after setting all properties.
function edit_outputPath_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_outputPath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_setName_Callback(hObject, eventdata, handles)
% hObject    handle to edit_setName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_setName as text
%        str2double(get(hObject,'String')) returns contents of edit_setName as a double


% --- Executes during object creation, after setting all properties.
function edit_setName_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_setName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushBrowse_output.
function pushBrowse_output_Callback(hObject, eventdata, handles)
% hObject    handle to pushBrowse_output (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
pathname=uigetdir('','Choose output path');
if isequal(pathname,0)
    return;
end
 %write the chosen file full name to the browse text box
 set(handles.edit_outputPath,'string',pathname);




function edit_modelPath_Callback(hObject, eventdata, handles)
% hObject    handle to edit_modelPath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_modelPath as text
%        str2double(get(hObject,'String')) returns contents of edit_modelPath as a double


% --- Executes during object creation, after setting all properties.
function edit_modelPath_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_modelPath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_modelFie.
function pushbutton_modelFie_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_modelFie (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename, pathname]=uigetfile({'*.mat'},'upload file');
if isequal(filename,0) || isequal(pathname,0)
    % TODO : add message box 
    return;
end
 %write the chosen file full name to the browse text box
 set(handles.edit_modelPath,'string',fullfile(pathname,filename));

% --- Executes on key press with focus on pushbutton_modelFie and none of its controls.
% hObject    handle to pushbutton_modelFie (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in checkbox_stat.
function checkbox_stat_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_stat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_stat
